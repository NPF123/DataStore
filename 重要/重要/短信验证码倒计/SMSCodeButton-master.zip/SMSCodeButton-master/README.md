# SMSCodeButton
可用作短信验证码的倒计时 Button


![Example screenshot](https://github.com/ChenYilong/SMSCodeButton/blob/master/iOS%20模拟器屏幕快照“2014年11月23日%20下午11.51.49”.png)



![Example screenshot](https://github.com/ChenYilong/SMSCodeButton/blob/master/iOS%20模拟器屏幕快照“2014年11月24日%20上午12.01.24”.png)



Check out [my weibo](http://weibo.com/luohanchenyilong/) for more info.

Check out [my twitter](https://twitter.com/stevechen1010) for more info.
