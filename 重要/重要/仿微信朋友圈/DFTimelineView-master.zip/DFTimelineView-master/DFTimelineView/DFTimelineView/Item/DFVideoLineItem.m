//
//  DFVideoLineItem.m
//  DFTimelineView
//
//  Created by Allen Zhong on 16/2/15.
//  Copyright © 2016年 Datafans, Inc. All rights reserved.
//

#import "DFVideoLineItem.h"

@implementation DFVideoLineItem

- (instancetype)init
{
    self = [super init];
    if (self) {
    
        _text = @"";
    }
    return self;
}

@end
