//
//  MLClickColorLinkLabel.h
//  DFTimelineView
//
//  Created by Allen Zhong on 15/10/15.
//  Copyright (c) 2015年 Datafans, Inc. All rights reserved.
//

#import "MLLinkClickLabel.h"

@interface MLClickColorLinkLabel : MLLinkClickLabel

@end
