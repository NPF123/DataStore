//
//  DFVideoLineCell.h
//  DFTimelineView
//
//  Created by Allen Zhong on 16/2/15.
//  Copyright © 2016年 Datafans, Inc. All rights reserved.
//

#import "DFBaseLineCell.h"

@interface DFVideoLineCell : DFBaseLineCell

@end
