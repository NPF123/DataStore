//
//  DFTextImageUserLineItem.m
//  DFTimelineView
//
//  Created by Allen Zhong on 15/10/15.
//  Copyright (c) 2015年 Datafans, Inc. All rights reserved.
//

#import "DFTextImageUserLineItem.h"

@implementation DFTextImageUserLineItem

- (instancetype)init
{
    self = [super init];
    if (self) {
    }
    return self;
}
@end
