//
//  ViewController.h
//  DFTimelineView
//
//  Created by Allen Zhong on 15/9/27.
//  Copyright (c) 2015年 Datafans, Inc. All rights reserved.
//

#import "DFTimelineView.h"

@interface ViewController : DFTimeLineViewController

@end

