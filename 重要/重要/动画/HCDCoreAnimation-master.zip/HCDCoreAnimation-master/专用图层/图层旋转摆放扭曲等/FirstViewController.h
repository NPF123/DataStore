//
//  FirstViewController.h
//  
//
//  Created by maiyun on 15/6/15.
//
//

#import <UIKit/UIKit.h>

@interface FirstViewController : UIViewController
@property(nonatomic,assign)NSInteger type;
@end
