//
//  WaveLoadingView.m
//  HCDWaveLoadingView
//
//  Created by 黄成都 on 16/3/13.
//  Copyright © 2016年 黄成都. All rights reserved.
//

#import "WaveLoadingView.h"

@implementation WaveLoadingView


-(void)awakeFromNib{
    self.amplitude_min = 16.0;
    self.amplitude_span = 26.0;
}


@end
