//
//  AppDelegate.h
//  HCDWaveLoadingView
//
//  Created by 黄成都 on 16/3/13.
//  Copyright © 2016年 黄成都. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

