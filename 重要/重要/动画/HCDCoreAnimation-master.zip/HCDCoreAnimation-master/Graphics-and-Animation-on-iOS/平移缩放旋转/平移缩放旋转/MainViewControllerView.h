//
//  MainViewControllerView.h
//  
//
//  Created by maiyun on 15/6/17.
//
//

#import <UIKit/UIKit.h>

@interface MainViewControllerView : UIView

@end
