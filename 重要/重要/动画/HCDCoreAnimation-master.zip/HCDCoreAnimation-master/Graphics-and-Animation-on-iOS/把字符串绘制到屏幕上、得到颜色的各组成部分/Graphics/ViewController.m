//
//  ViewController.m
//  Graphics
//
//  Created by maiyun on 15/6/16.
//  Copyright (c) 2015年 黄成都. All rights reserved.
//

#import "ViewController.h"
#import "GraphicsViewControllerView.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
//    GraphicsViewControllerView *GView = [[GraphicsViewControllerView alloc]init];
//    GView.frame = self.view.frame;
//    [self.view addSubview:GView];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
