# HCDCoreAnimation
[iOS核心动画高级技巧](https://www.gitbook.com/book/zsisme/ios-/details)
</br>
各种动画装逼技巧。此为学习这本书籍的时候写的一些demo。
</br>
马上会有大量的更新。敬请期待。

##:关于图层
</br>
  ![image](https://github.com/huang303513/HCDCoreAnimation/blob/master/%E5%9B%BE%E5%B1%82%E7%9B%B8%E5%85%B3%E7%9F%A5%E8%AF%86%E2%80%94%E2%80%941%EF%BC%8C2%EF%BC%8C3%E7%AB%A0/%E5%9B%BE%E5%B1%82%E7%9B%B8%E5%85%B3123%E7%AB%A0.gif)
</br>
##:动画缓冲
</br>
 ![image](https://github.com/huang303513/HCDCoreAnimation/blob/master/%E5%8A%A8%E7%94%BB%E7%BC%93%E5%86%B2/%E5%8A%A8%E7%94%BB%E7%BC%93%E5%86%B2.gif)
</br>
##:专用图层
</br>
![image](https://github.com/huang303513/HCDCoreAnimation/blob/master/screenshot/%E4%B8%93%E7%94%A8%E5%9B%BE%E5%B1%82.gif)
</br>
##:图片实现时钟
</br>
![image](https://github.com/huang303513/HCDCoreAnimation/blob/master/screenshot/%E6%97%B6%E9%92%9F.gif)
</br>
##:显式动画
</br>
![image](https://github.com/huang303513/HCDCoreAnimation/blob/master/screenshot/%E6%98%BE%E5%BC%8F%E5%8A%A8%E7%94%BB.gif)
</br>
##:视图动画
</br>
![image](https://github.com/huang303513/HCDCoreAnimation/blob/master/screenshot/%E8%A7%86%E5%9B%BE%E5%8A%A8%E7%94%BB.gif)
</br>


