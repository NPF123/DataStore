//
//  ViewController.h
//  GGBannerViewDemo
//
//  Created by GuinsooMBP on 15/8/29.
//  Copyright (c) 2015年 gaonan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

