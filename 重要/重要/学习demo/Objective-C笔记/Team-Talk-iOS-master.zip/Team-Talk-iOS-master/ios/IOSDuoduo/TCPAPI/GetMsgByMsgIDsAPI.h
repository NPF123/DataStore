//
//  GetMsgByMsgIDsAPI.h
//  TeamTalk
//
//  Created by Michael Scofield on 2015-02-05.
//  Copyright (c) 2015 Michael Hu. All rights reserved.
//

#import "DDSuperAPI.h"

@interface GetMsgByMsgIDsAPI : DDSuperAPI

@end
