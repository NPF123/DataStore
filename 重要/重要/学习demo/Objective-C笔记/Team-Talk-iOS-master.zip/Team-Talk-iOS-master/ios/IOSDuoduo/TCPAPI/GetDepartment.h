//
//  GetDepartment.h
//  TeamTalk
//
//  Created by Michael Scofield on 2015-03-16.
//  Copyright (c) 2015 Michael Hu. All rights reserved.
//

#import "DDSuperAPI.h"

@interface GetDepartment : DDSuperAPI

@end
