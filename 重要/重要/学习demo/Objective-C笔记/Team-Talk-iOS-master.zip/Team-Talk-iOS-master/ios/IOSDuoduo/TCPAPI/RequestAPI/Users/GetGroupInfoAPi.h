//
//  GetGroupInfoAPi.h
//  TeamTalk
//
//  Created by Michael Scofield on 2014-09-18.
//  Copyright (c) 2014 dujia. All rights reserved.
//

#import "DDSuperAPI.h"

@interface GetGroupInfoAPI : DDSuperAPI

@end
