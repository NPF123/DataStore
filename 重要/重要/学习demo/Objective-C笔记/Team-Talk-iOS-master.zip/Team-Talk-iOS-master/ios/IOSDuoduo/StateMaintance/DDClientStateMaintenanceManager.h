//
//  DDClientStateMaintenanceManager.h
//  Duoduo
//
//  Created by 独嘉 on 14-4-12.
//  Copyright (c) 2014年 mogujie. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 *  自身状态的维护
 */
@interface DDClientStateMaintenanceManager : NSObject

+ (instancetype)shareInstance;

@end
