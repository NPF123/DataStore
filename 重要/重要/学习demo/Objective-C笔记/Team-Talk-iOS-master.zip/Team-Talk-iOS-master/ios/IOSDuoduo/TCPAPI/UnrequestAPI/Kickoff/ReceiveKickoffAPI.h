//
//  DDReceiveKickoffAPI.h
//  Mogujie4iPhone
//
//  Created by 独嘉 on 14-6-29.
//  Copyright (c) 2014年 juangua. All rights reserved.
//

#import "DDUnrequestSuperAPI.h"

@interface ReceiveKickoffAPI : DDUnrequestSuperAPI<DDAPIUnrequestScheduleProtocol>

@end
