//
//  GetRecentSession.h
//  TeamTalk
//
//  Created by Michael Scofield on 2014-12-03.
//  Copyright (c) 2014 dujia. All rights reserved.
//

#import "DDSuperAPI.h"

@interface GetRecentSession : DDSuperAPI

@end
