//
//  GetMessageQueueAPI.h
//  TeamTalk
//
//  Created by Michael Scofield on 2014-12-08.
//  Copyright (c) 2014 dujia. All rights reserved.
//

#import "DDSuperAPI.h"

@interface GetMessageQueueAPI : DDSuperAPI

@end
