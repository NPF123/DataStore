//
//  NSString+DDPath.h
//  IOSDuoduo
//
//  Created by 独嘉 on 14-6-3.
//  Copyright (c) 2014年 dujia. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (DDPath)
+ (NSString*)userExclusiveDirection;
@end
