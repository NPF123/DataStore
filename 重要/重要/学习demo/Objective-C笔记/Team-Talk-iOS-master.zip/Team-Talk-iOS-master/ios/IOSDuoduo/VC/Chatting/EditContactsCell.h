//
//  EditContactsCell.h
//  TeamTalk
//
//  Created by Michael Scofield on 2014-09-10.
//  Copyright (c) 2014 dujia. All rights reserved.
//

#import "DDContactsCell.h"

@interface EditContactsCell : DDContactsCell
-(void)setCellToSelected:(BOOL)select;
@end
