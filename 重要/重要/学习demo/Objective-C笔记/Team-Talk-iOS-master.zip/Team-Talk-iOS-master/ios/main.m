//
//  main.m
//  IOSDuoduo
//
//  Created by 独嘉 on 14-5-23.
//  Copyright (c) 2014年 dujia. All rights reserved.
//
//jide viewed

#import <UIKit/UIKit.h>

#import "DDAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([DDAppDelegate class]));
    }
}
