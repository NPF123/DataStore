//
//  AKB48.h
//  27_SEL
//
//  Created by SuzukiAlrcly on 15/6/23.
//  Copyright (c) 2015年 SuzukiAlrcly. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AKB48 : NSObject

+ (void)test;

- (void)test2;

- (void)test3:(NSString *)abc;
@end
