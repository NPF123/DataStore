//
//  Student.h
//  27_成员变量的作用域
//
//  Created by SuzukiAlrcly on 15/6/15.
//  Copyright (c) 2015年 SuzukiAlrcly. All rights reserved.
//

#import "person.h"

@interface Student : Person
- (void)study;
@end
