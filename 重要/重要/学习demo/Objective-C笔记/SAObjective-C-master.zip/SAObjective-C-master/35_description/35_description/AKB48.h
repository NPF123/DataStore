//
//  AKB48.h
//  35_description
//
//  Created by SuzukiAlrcly on 15/6/23.
//  Copyright (c) 2015年 SuzukiAlrcly. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AKB48 : NSObject
@property int 年龄;
@property NSString *名字;
@end
