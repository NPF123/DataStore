//
//  AKB48.h
//  36_NSLog输出
//
//  Created by SuzukiAlrcly on 15/6/23.
//  Copyright (c) 2015年 SuzukiAlrcly. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AKB48 : NSObject
@property int age;
@end
