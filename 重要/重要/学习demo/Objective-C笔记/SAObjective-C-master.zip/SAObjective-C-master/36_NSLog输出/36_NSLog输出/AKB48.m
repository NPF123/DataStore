//
//  AKB48.m
//  36_NSLog输出
//
//  Created by SuzukiAlrcly on 15/6/23.
//  Copyright (c) 2015年 SuzukiAlrcly. All rights reserved.
//

#import "AKB48.h"

@implementation AKB48

@end
