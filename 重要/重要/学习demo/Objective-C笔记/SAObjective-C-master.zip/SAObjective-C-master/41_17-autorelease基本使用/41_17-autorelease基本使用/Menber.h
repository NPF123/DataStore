//
//  Menber.h
//  41_17-autorelease基本使用
//
//  Created by SuzukiAlrcly on 15/6/28.
//  Copyright (c) 2015年 SuzukiAlrcly. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Menber : NSObject
@property (nonatomic,assign) int age;
@end
