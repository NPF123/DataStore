//
//  SNH48+Alrcly.h
//  34_ 类的本质
//
//  Created by SuzukiAlrcly on 15/6/23.
//  Copyright (c) 2015年 SuzukiAlrcly. All rights reserved.
//

#import "SNH48.h"

@interface SNH48 (Alrcly)

@end
