//
//  SNH48+Alrcly.m
//  34_ 类的本质
//
//  Created by SuzukiAlrcly on 15/6/23.
//  Copyright (c) 2015年 SuzukiAlrcly. All rights reserved.
//

#import "SNH48+Alrcly.h"

@implementation SNH48 (Alrcly)
+ (void)load{
    NSLog(@"调用了SNH48(Alrcly)_load方法");
}

+ (void)initialize{
    NSLog(@"SNH48(Alrcly)_initialize");
}
@end
