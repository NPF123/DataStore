//
//  GoodAKB48.m
//  34_ 类的本质
//
//  Created by SuzukiAlrcly on 15/6/23.
//  Copyright (c) 2015年 SuzukiAlrcly. All rights reserved.
//

#import "GoodAKB48.h"

@implementation GoodAKB48
+ (void)load{
    NSLog(@"调用了GoodAKB48_load方法");
}

+ (void)initialize{
    NSLog(@"AKB48Good_initialize");
}
@end
