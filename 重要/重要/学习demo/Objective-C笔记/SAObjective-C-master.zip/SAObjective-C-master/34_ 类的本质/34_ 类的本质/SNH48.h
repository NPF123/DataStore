//
//  SNH48.h
//  34_ 类的本质
//
//  Created by SuzukiAlrcly on 15/6/21.
//  Copyright (c) 2015年 SuzukiAlrcly. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SNH48 : NSObject
+ (void)test;
@end
