//
//  GoodAKB48.h
//  34_ 类的本质
//
//  Created by SuzukiAlrcly on 15/6/23.
//  Copyright (c) 2015年 SuzukiAlrcly. All rights reserved.
//

#import "AKB48.h"

@interface GoodAKB48 : AKB48

@end
