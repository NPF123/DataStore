//
//  main.m
//  39_property的内存管理
//
//  Created by SuzukiAlrcly on 15/6/27.
//  Copyright (c) 2015年 SuzukiAlrcly. All rights reserved.
//

#import <Foundation/Foundation.h>

int main() {
        
    NSLog(@"ただ、君を爱してる");

    return 0;
}
