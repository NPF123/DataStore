//
//  Gclass.m
//  39_property的内存管理
//
//  Created by SuzukiAlrcly on 15/6/27.
//  Copyright (c) 2015年 SuzukiAlrcly. All rights reserved.
//

#import "Gclass.h"

@implementation Gclass

@end
