//
//  SNH48.m
//  31_Category_分类
//
//  Created by SuzukiAlrcly on 15/6/17.
//  Copyright (c) 2015年 SuzukiAlrcly. All rights reserved.
//

#import "SNH48.h"

@implementation SNH48
- (void)test
{
    NSLog(@"调用了test方法");
}
@end
