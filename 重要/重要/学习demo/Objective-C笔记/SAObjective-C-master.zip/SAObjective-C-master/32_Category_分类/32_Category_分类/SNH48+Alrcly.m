//
//  SNH48+Alrcly.m
//  31_Category_分类
//
//  Created by SuzukiAlrcly on 15/6/17.
//  Copyright (c) 2015年 SuzukiAlrcly. All rights reserved.
//

#import "SNH48+Alrcly.h"

@implementation SNH48 (Alrcly)
- (void) Play
{
    NSLog(@"放假的感觉真是好！");
}
@end
