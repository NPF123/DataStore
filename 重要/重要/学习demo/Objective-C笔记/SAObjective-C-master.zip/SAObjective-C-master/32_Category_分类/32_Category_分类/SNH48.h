//
//  SNH48.h
//  31_Category_分类
//
//  Created by SuzukiAlrcly on 15/6/17.
//  Copyright (c) 2015年 SuzukiAlrcly. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SNH48 : NSObject
- (void)test;
@end
