//
//  AKB48.h
//  44_ARC的基本使用
//
//  Created by SuzukiAlrcly on 15/7/6.
//  Copyright (c) 2015年 SuzukiAlrcly. All rights reserved.
//

#import <Foundation/Foundation.h>

@class Dog;


@interface AKB48 : NSObject
@property (nonatomic,strong) Dog* dog;
@end
