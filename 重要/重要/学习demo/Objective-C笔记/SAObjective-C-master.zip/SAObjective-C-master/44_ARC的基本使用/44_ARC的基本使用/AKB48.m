//
//  AKB48.m
//  44_ARC的基本使用
//
//  Created by SuzukiAlrcly on 15/7/6.
//  Copyright (c) 2015年 SuzukiAlrcly. All rights reserved.
//

#import "AKB48.h"

@implementation AKB48

- (void)dealloc{
    NSLog(@"AKB is dealloc");
}
@end
