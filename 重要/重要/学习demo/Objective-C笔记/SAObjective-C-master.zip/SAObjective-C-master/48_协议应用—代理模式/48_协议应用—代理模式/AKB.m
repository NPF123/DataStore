//
//  AKB.m
//  48_协议应用—代理模式
//
//  Created by SuzukiAlrcly on 15/7/6.
//  Copyright (c) 2015年 SuzukiAlrcly. All rights reserved.
//

#import "AKB.h"

@implementation AKB
//剩余的票数
- (int)leftTicketsNUmber{
    return 1;
}

//第一张标多少钱
- (double)ticketPrice{
    return 450;
}
@end
