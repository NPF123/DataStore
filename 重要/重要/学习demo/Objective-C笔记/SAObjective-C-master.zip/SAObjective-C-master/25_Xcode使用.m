//
//  Piese.m
//  123
//
//  Created by SuzukiAlrcly on 15/6/15.
//  Copyright (c) 2015年 SuzukiAlrcly. All rights reserved.
//

#import "Piese.h"

@implementation Piese
- (void)Great
{
    
}

- (int)get
{
    return _SSS ;
}

#pragma mark - 这样不是很好吗？
- (void)seta:(int)newa;
{
    _SSS = newa;
}
@end
