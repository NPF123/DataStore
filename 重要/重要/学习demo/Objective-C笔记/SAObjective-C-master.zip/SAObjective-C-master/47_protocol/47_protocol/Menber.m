//
//  Menber.m
//  47_protocol
//
//  Created by SuzukiAlrcly on 15/7/6.
//  Copyright (c) 2015年 SuzukiAlrcly. All rights reserved.
//

#import "Menber.h"

@implementation Menber
- (void)test{
    
}

- (void)test2{
    
}

- (void)akb{
    
}
- (void)snh{
    
}
@end
