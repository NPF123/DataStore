//
//  Myprotocol3.h
//  47_protocol
//
//  Created by SuzukiAlrcly on 15/7/6.
//  Copyright (c) 2015年 SuzukiAlrcly. All rights reserved.
//

#import <Foundation/Foundation.h>


//只要一个协议遵守了某一份协议，就能拥有这份协议中的所有方法声明
@protocol Myprotocol3 <Myprotocol>

@end
