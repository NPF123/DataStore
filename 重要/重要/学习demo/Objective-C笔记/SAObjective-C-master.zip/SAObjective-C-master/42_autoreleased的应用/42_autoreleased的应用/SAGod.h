//
//  SAGod.h
//  42_autoreleased的应用
//
//  Created by SuzukiAlrcly on 15/6/28.
//  Copyright (c) 2015年 SuzukiAlrcly. All rights reserved.
//

#import "Menber.h"

@interface SAGod : Menber
@property (nonatomic,assign) int money;
@end
