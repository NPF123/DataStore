//
//  Cute.h
//  30_构造方法
//
//  Created by SuzukiAlrcly on 15/6/16.
//  Copyright (c) 2015年 SuzukiAlrcly. All rights reserved.
//

#import "Person.h"

@interface Cute : Person
@property int no;

@end
