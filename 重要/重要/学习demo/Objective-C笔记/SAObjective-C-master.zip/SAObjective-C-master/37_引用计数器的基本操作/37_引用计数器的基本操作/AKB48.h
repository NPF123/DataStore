//
//  AKB48.h
//  37_引用计数器的基本操作
//
//  Created by SuzukiAlrcly on 15/6/25.
//  Copyright (c) 2015年 SuzukiAlrcly. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AKB48 : NSObject
@property int age;
@end
