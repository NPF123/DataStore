//
//  Person.m
//  29_ID
//
//  Created by SuzukiAlrcly on 15/6/16.
//  Copyright (c) 2015年 SuzukiAlrcly. All rights reserved.
//

#import "Person.h"

@implementation Person

@end
