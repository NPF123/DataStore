//
//  SLContactsEmail.h
//  SLAddressBook
//
//  Created by wshaolin on 14-6-3.
//  Copyright (c) 2014年 wshaolin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SLContactsEmail : NSObject

@property (nonatomic, copy) NSString *type;

@property (nonatomic, copy) NSString *emailText;

@end
