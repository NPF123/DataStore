//
//  SLContactsPhone.h
//  SLAddressBook
//
//  Created by wshaolin on 14-6-3.
//  Copyright (c) 2014年 wshaolin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SLContactsPhone : NSObject

@property (nonatomic, copy) NSString *type;

@property (nonatomic, copy) NSString *phone;

@end
