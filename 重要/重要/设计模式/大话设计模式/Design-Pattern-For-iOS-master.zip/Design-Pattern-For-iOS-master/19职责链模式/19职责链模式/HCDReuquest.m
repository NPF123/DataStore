//
//  HCDReuquest.m
//  19职责链模式
//
//  Created by yifan on 15/8/15.
//  Copyright (c) 2015年 黄成都. All rights reserved.
//

#import "HCDReuquest.h"

@implementation HCDReuquest

@end
