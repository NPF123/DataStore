//
//  HCDnokiaPhone.m
//  3装饰模式
//
//  Created by yifan on 15/8/12.
//  Copyright (c) 2015年 黄成都. All rights reserved.
//

#import "HCDnokiaPhone.h"

@implementation HCDnokiaPhone
- (NSString *)callNumber{
    return @"Nokiaphone call somebody";
}
-(NSString *)sendMessage{
    return @"NokiaPhone send message to somebody";
}
@end
