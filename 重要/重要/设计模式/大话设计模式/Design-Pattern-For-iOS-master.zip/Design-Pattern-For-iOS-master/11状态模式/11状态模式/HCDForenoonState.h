//
//  HCDForenoonState.h
//  11状态模式
//
//  Created by yifan on 15/8/14.
//  Copyright (c) 2015年 黄成都. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HCDState.h"
@interface HCDForenoonState : NSObject<HCDState>

@end
