//
//  HCDstock1.m
//  7外观模式
//
//  Created by yifan on 15/8/13.
//  Copyright (c) 2015年 黄成都. All rights reserved.
//

#import "HCDstock1.h"

@implementation HCDstock1
-(void)buy{
    NSLog(@"买入股票1");
}
-(void)sell{
    NSLog(@"卖出股票1");
}
@end
