//
//  HCDstock1.h
//  7外观模式
//
//  Created by yifan on 15/8/13.
//  Copyright (c) 2015年 黄成都. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HCDstock1 : NSObject
-(void)buy;
-(void)sell;
@end
