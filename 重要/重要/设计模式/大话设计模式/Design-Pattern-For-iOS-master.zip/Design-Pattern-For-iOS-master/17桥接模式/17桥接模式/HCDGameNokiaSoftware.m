//
//  HCDGameNokiaSoftware.m
//  17桥接模式
//
//  Created by yifan on 15/8/15.
//  Copyright (c) 2015年 黄成都. All rights reserved.
//

#import "HCDGameNokiaSoftware.h"

@implementation HCDGameNokiaSoftware
-(void)run{
    NSLog(@"运行Nokia的游戏软件");
}
@end
