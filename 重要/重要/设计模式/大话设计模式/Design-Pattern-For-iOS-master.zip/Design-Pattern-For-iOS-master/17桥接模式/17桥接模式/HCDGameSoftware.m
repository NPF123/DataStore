//
//  HCDGameSoftware.m
//  17桥接模式
//
//  Created by yifan on 15/8/15.
//  Copyright (c) 2015年 黄成都. All rights reserved.
//

#import "HCDGameSoftware.h"

@implementation HCDGameSoftware
-(void)run{
    NSLog(@"运行游戏手机软件");
}
@end
