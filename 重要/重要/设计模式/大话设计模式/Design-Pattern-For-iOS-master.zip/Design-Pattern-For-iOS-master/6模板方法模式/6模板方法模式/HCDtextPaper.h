//
//  HCDtextPaper.h
//  6模板方法模式
//
//  Created by yifan on 15/8/12.
//  Copyright (c) 2015年 黄成都. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HCDtextPaper : NSObject
- (void)testQuestion1;
- (NSString *)answer1;
- (void)testQuestion2;
- (NSString *)answer2;
@end
