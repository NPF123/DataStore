//
//  HCDtextPaperB.h
//  6模板方法模式
//
//  Created by yifan on 15/8/12.
//  Copyright (c) 2015年 黄成都. All rights reserved.
//

#import "HCDtextPaper.h"

@interface HCDtextPaperB : HCDtextPaper

@end
