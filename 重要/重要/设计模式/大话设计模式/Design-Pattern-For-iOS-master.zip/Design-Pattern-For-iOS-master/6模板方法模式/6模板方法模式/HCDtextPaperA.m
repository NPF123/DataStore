//
//  HCDtextPaperA.m
//  6模板方法模式
//
//  Created by yifan on 15/8/12.
//  Copyright (c) 2015年 黄成都. All rights reserved.
//

#import "HCDtextPaperA.h"

@implementation HCDtextPaperA
-(NSString *)answer1{
    return @"b";
}
-(NSString *)answer2{
    return @"c";
}
@end
