//
//  LCUserFeedbackImageViewController.h
//  LeanCloudFeedback
//
//  Created by lzw on 15/7/21.
//  Copyright (c) 2015年 LeanCloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LCUserFeedbackImageViewController : UIViewController

@property (nonatomic, strong) UIImage *image;

@end
