//
//  CYLTabBarControllerConfig.h
//  CYLTabBarController
//
//  Created by 陈宜龙 on 15/11/3.
//  Copyright © 2015年 微博@iOS程序犭袁. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CYLTabBarController.h"

@interface CYLTabBarControllerConfig : NSObject

@property (nonatomic, readonly, strong) CYLTabBarController *tabBarController;

@end
