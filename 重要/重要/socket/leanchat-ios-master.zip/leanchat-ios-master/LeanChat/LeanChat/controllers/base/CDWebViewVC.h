//
//  CDWebViewVC.h
//  LeanChat
//
//  Created by lzw on 15/4/28.
//  Copyright (c) 2015年 LeanCloud. All rights reserved.
//

#import "CDBaseVC.h"

@interface CDWebViewVC : CDBaseVC

- (instancetype)initWithURL:(NSURL *)url title:(NSString *)title;

@end
