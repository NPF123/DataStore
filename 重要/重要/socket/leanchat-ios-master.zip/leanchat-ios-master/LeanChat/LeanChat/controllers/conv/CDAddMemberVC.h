//
//  CDGroupAddMemberController.h
//  LeanChat
//
//  Created by lzw on 14/11/7.
//  Copyright (c) 2014年 LeanCloud. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CDConvDetailVC.h"
#import "CDBaseTableVC.h"

@interface CDAddMemberVC : CDBaseTableVC

@property (nonatomic) CDConvDetailVC *groupDetailVC;

@end
