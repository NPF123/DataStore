//
//  CDConvReportAbuseVC.h
//  LeanChat
//
//  Created by lzw on 15/4/29.
//  Copyright (c) 2015年 LeanCloud. All rights reserved.
//

#import "CDBaseVC.h"

@interface CDConvReportAbuseVC : CDBaseVC

- (instancetype)initWithConversationId:(NSString *)convid;

@end
