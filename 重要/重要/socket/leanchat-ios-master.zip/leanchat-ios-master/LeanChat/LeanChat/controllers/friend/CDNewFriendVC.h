//
//  CDNewFriendTableViewController.h
//  LeanChat
//
//  Created by lzw on 14-10-23.
//  Copyright (c) 2014年 LeanCloud. All rights reserved.
//

#import "CDBaseTableVC.h"
#import "CDFriendListVC.h"

@interface CDNewFriendVC : CDBaseTableVC

@property CDFriendListVC *friendListVC;

@end
