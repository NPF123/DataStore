//
//  CDPushSettingController.h
//  LeanChat
//
//  Created by lzw on 15/1/15.
//  Copyright (c) 2015年 LeanCloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CDSettingVC : UITableViewController


@end

