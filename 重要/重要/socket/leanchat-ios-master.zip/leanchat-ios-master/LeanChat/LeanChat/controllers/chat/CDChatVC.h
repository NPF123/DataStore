//
//  CDChatVC.h
//  LeanChat
//
//  Created by lzw on 15/4/10.
//  Copyright (c) 2015年 LeanCloud. All rights reserved.
//


#import <LeanChatLib/CDChatRoomVC.h>

@interface CDChatVC : CDChatRoomVC

@end
