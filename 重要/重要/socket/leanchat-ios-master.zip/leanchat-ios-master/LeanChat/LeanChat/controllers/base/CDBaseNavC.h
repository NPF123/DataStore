//
//  CDBaseNavigationController.h
//  LeanChat
//
//  Created by Qihe Bian on 7/24/14.
//  Copyright (c) 2014 LeanCloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CDBaseNavC : UINavigationController

@end
