//
//  CDPhoneRegisterVC.h
//  LeanChat
//
//  Created by lzw on 15/8/10.
//  Copyright (c) 2015年 LeanCloud（Bug汇报：QQ1356701892）.  All rights reserved.
//

#import "CDEntryBaseVC.h"

@interface CDPhoneRegisterVC : CDEntryBaseVC

@end
