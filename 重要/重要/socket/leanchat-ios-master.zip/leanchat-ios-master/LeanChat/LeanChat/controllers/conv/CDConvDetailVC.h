//
//  CDGroupDetailController.h
//  LeanChat
//
//  Created by lzw on 14/11/6.
//  Copyright (c) 2014年 LeanCloud. All rights reserved.
//

#import "CDBaseTableVC.h"

@interface CDConvDetailVC : CDBaseTableVC

@end
