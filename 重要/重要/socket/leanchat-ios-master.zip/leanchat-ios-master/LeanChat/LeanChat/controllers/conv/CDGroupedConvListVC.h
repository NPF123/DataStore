//
//  CDGroupTableViewController.h
//
//
//  Created by lzw on 14/11/6.
//
//

#import <UIKit/UIKit.h>
#import "CDBaseTableVC.h"

@interface CDGroupedConvListVC : CDBaseTableVC

@end
