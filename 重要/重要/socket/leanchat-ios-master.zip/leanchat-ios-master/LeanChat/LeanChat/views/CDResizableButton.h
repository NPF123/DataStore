//
//  ResizableButton.h
//  LeanChat
//
//  Created by lzw on 14/11/4.
//  Copyright (c) 2014年 LeanCloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CDResizableButton : UIButton

@end
