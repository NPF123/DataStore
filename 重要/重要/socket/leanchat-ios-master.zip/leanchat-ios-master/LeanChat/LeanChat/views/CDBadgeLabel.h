//
//  CDBadgeLabel.h
//  LeanChat
//
//  Created by lzw on 15/1/12.
//  Copyright (c) 2015年 LeanCloud. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface CDBadgeLabel : UILabel

- (void)setNormalStyle;

@end
