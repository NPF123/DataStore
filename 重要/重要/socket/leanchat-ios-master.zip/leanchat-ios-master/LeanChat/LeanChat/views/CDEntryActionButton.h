//
//  CDEntryActionButton.h
//  LeanChat
//
//  Created by lzw on 15/5/21.
//  Copyright (c) 2015年 LeanCloud. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CDResizableButton.h"

@interface CDEntryActionButton : CDResizableButton

@end
