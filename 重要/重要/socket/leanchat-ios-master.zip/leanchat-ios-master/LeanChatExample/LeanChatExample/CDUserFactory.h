//
//  CDUserFactory.h
//  LeanChatExample
//
//  Created by lzw on 15/4/7.
//  Copyright (c) 2015年 avoscloud. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <LeanChatLib/LeanChatLib.h>

@interface CDUserFactory : NSObject <CDUserDelegate>

@end
