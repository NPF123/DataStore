//
//  LCEChatRoomVC.h
//  LeanChatExample
//
//  Created by lzw on 15/4/7.
//  Copyright (c) 2015年 avoscloud. All rights reserved.
//

#import <LeanChatLib/LeanChatLib.h>

@interface LCEChatRoomVC : CDChatRoomVC

@end
