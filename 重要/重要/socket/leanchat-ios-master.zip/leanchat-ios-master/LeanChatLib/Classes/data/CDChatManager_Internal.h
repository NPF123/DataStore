//
//  ChatManager_Internal.h
//  LeanChatLib
//
//  Created by lzw on 15/7/31.
//  Copyright (c) 2015年 LeanCloud（Bug汇报：QQ1356701892）.  All rights reserved.
//

#import "CDChatManager.h"

@interface  CDChatManager ()

/**
 *  推送弹框点击时记录的 convid
 */
@property (nonatomic, strong) NSString *remoteNotificationConvid;

@end
