//
//  ChatRoomViewController.swift
//  LeanChatSwift
//
//  Created by lzw on 15/11/17.
//  Copyright © 2015年 LeanCloud. All rights reserved.
//

import Foundation

class ChatRoomViewController: CDChatRoomVC {
}