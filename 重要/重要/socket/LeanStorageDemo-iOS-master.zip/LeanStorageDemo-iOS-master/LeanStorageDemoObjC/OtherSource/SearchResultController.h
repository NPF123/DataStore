//
//  SearchResultController.h
//  AVOSDemo
//
//  Created by Qihe Bian on 6/9/14.
//  Copyright (c) 2014 AVOS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchResultController : UITableViewController
@property (nonatomic, strong) NSArray *objects;
@end
