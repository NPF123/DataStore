//
//  ImageViewController.h
//  LeanStorageDemo
//
//  Created by lzw on 15/6/7.
//  Copyright (c) 2015年 LeanCloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ImageViewController : UIViewController

@property (nonatomic, strong) UIImage *image;

@end
