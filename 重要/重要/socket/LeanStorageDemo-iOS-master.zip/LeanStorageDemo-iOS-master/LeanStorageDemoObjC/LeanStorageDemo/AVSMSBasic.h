//
//  AVSNSBasic.h
//  AVOSDemo
//
//  Created by lzw on 15/5/21.
//  Copyright (c) 2015年 LeanCloud. All rights reserved.
//

#import "Demo.h"

@interface AVSMSBasic : Demo

@end
