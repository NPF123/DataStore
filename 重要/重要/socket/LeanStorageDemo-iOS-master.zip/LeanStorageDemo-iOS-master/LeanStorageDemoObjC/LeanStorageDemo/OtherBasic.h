//
//  OtherBasic.h
//  LeanStorageDemo
//
//  Created by lzw on 15/8/20.
//  Copyright (c) 2015年 LeanCloud. All rights reserved.
//

#import "Demo.h"

@interface OtherBasic : Demo

@end
