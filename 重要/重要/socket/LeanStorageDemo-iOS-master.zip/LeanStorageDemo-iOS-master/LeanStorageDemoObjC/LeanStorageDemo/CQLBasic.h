//
//  CQLBasic.h
//  LeanStorageDemo
//
//  Created by lzw on 15/6/7.
//  Copyright (c) 2015年 LeanCloud. All rights reserved.
//

#import "Demo.h"

@interface CQLBasic : Demo

@end
