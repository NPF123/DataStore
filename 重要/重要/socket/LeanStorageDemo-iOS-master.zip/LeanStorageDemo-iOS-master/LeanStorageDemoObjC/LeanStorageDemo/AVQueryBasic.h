//
//  AVQueryBasic.h
//  AVOSDemo
//
//  Created by Travis on 13-12-12.
//  Copyright (c) 2013年 AVOS. All rights reserved.
//

#import "Demo.h"

@interface AVQueryBasic : Demo

@end
