//
//  EngineBasic.h
//  LeanStorageDemo
//
//  Created by lzw on 15/8/21.
//  Copyright (c) 2015年 AVOS. All rights reserved.
//

#import "Demo.h"

@interface EngineBasic : Demo

@end
