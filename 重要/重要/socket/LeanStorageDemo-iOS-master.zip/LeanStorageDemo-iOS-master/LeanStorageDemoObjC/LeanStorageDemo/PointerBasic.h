//
//  PointerBasic.h
//  LeanStorageDemo
//
//  Created by lzw on 15/8/19.
//  Copyright (c) 2015年 LeanCloud. All rights reserved.
//

#import "Demo.h"

@interface PointerBasic : Demo

@end
