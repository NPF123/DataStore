//
//  AVAnalyticsBasic.h
//  AVOSDemo
//
//  Created by Travis on 13-12-23.
//  Copyright (c) 2013年 AVOS. All rights reserved.
//

#import "Demo.h"

@interface AVAnalyticsBasic : Demo

@end
