//
//  NSDictionary+log.h
//  
//
//  Created by CHENYI LONG on 14-8-10.
//  Copyright (c) 2014年 CHENYI LONG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (log)

@end
