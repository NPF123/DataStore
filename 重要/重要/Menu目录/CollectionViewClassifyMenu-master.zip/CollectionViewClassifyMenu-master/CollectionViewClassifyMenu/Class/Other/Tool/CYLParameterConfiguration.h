//
//  CYLParameterConfiguration.h
//  CollectionViewClassifyMenu
//
//  Created by 陈宜龙 on 16/1/6.
//  Copyright © 2016年 chenyilong. All rights reserved.
//

#define CYLAppTintColor [UIColor colorWithRed:42 / 255.0 green:185 / 255.0 blue:160 / 255.0 alpha:1]
#define  CYLTagTitleFont [UIFont systemFontOfSize:16]