//
//  CYLMainViewController.h
//  CollectionViewClassifyMenu
//
//  Created by https://github.com/ChenYilong on 15/4/26.
//  Copyright (c)  http://weibo.com/luohanchenyilong/ . All rights reserved.
//

#import "CYLClassifyMenuViewController.h"

@interface CYLMainViewController : CYLClassifyMenuViewController

@end
