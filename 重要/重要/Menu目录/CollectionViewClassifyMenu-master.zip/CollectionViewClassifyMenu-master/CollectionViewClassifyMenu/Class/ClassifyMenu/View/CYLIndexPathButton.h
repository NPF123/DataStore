//
//  CYLIndexPathButton.h
//  CollectionViewClassifyMenu
//
//  Created by https://github.com/ChenYilong on 15/3/19.
//  Copyright (c)  http://weibo.com/luohanchenyilong/ . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CYLIndexPathButton : UIButton

@property (nonatomic, assign) NSInteger section;
@property (nonatomic, assign) NSInteger row;

@end
