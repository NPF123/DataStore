//
//  CYLIndexPathButton.m
//  CollectionViewClassifyMenu
//
//  Created by https://github.com/ChenYilong on 15/3/19.
//  Copyright (c)  http://weibo.com/luohanchenyilong/ . All rights reserved.
//

#import "CYLIndexPathButton.h"

@implementation CYLIndexPathButton

@end
