//
//  FilterCollectionCell.h
//  http://cnblogs.com/ChenYilong/ 
//
//  Created by  https://github.com/ChenYilong  on 14-7-9.
//  Copyright (c)  http://weibo.com/luohanchenyilong/  . All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CYLIndexPathButton.h"

@interface FilterCollectionCell : UICollectionViewCell

@property (nonatomic, strong) CYLIndexPathButton *titleButton;

@end
