//
//  CYLMultipleFilterController.h
//  http://cnblogs.com/ChenYilong/ 
//
//  Created by  https://github.com/ChenYilong  on 14-7-10.
//  Copyright (c)  http://weibo.com/luohanchenyilong/  . All rights reserved.
//  CYLMultipleFilterController Choice Storage Filter

#import "FilterBaseController.h"

@interface CYLMultipleFilterController : FilterBaseController

- (void)refreshFilterParams;

@end
