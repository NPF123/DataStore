//
//  CYLDetailsViewController.h
//  CYLTabBarController
//
//  Created by Robert Dimitrov on 11/8/14.
//  Copyright (c) 2014 Robert Dimitrov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CYLDetailsViewController : UIViewController

@end
