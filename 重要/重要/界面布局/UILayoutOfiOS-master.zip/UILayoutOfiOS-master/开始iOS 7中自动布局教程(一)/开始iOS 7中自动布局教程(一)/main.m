//
//  main.m
//  开始iOS 7中自动布局教程(一)
//
//  Created by huangchengdu on 16/1/21.
//  Copyright © 2016年 huangchengdu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
