#各种自动布局、cell高度计算的解决方案、可以下载综合权衡。


[IOS页面自动布局 之 NSLayoutConstraint基础篇](http://www.cnblogs.com/xieyajie/p/4612697.html?utm_source=tuicool&utm_medium=referral)


[Masonry各种用法](https://github.com/ming1016/study/wiki/Masonry)

[Masonry的使用](http://liuyanwei.jumppo.com/2015/06/14/ios-library-masonry.html)

[动态计算UITableViewCell高度详解](http://www.cocoachina.com/industry/20140604/8668.html)

[AutoLayout框架Masonry使用心得](http://www.starming.com/index.php?v=index&view=81)

[有趣的Autolayout示例3-Masonry实现](http://tutuge.me/2015/12/14/autolayout-example-with-masonry3/)

[有趣的Autolayout示例-Masonry实现](http://tutuge.me/2015/05/23/autolayout-example-with-masonry/)


xib和SB的自动布局：

[叶孤城SizeClass和AutoLayout教程1](http://www.jianshu.com/p/bd071f9a558d)

[叶孤城SizeClass和AutoLayout教程2](http://www.jianshu.com/p/a4cf3db81c0b)

[叶孤城SizeClass和AutoLayout教程3](http://www.jianshu.com/p/3d6b2341fd83)

[叶孤城SizeClass和AutoLayout教程4](http://www.jianshu.com/p/e72e957497b3)

[UI布局（一）初探Size Class ](http://blog.csdn.net/liangliang103377/article/details/40082231)

[UI布局（二）storyboard中autolayout和size class的使用详解](http://blog.csdn.net/liangliang103377/article/details/40082255)

[UI布局（三）深入理解autolayout](http://blog.csdn.net/liangliang103377/article/details/40082271)

[开始iOS 7中自动布局教程一](http://www.cnblogs.com/zer0Black/p/3977134.html)

[开始iOS 7中自动布局教程(二)](http://www.cnblogs.com/zer0Black/p/3977288.html)
