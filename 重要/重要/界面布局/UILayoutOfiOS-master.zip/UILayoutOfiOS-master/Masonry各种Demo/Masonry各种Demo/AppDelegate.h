//
//  AppDelegate.h
//  Masonry各种Demo
//
//  Created by yifan on 15/8/7.
//  Copyright (c) 2015年 黄成都. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

