//
//  firstTableViewCell.swift
//  AutoLayout
//
//  Created by yifan on 15/9/6.
//  Copyright (c) 2015年 黄成都. All rights reserved.
//

import UIKit

class firstTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
