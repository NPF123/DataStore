//
//  UI_____storyboard_autolayout_size_classUI_____storyboard_autolayout_size_UI_____storyboard_autolayout_size_classTests.m
//  UI布局（二）storyboard中autolayout和size classUI布局（二）storyboard中autolayout和size UI布局(二)storyboard中autolayout和size classTests
//
//  Created by huangchengdu on 16/1/20.
//  Copyright © 2016年 huangchengdu. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface UI_____storyboard_autolayout_size_classUI_____storyboard_autolayout_size_UI_____storyboard_autolayout_size_classTests : XCTestCase

@end

@implementation UI_____storyboard_autolayout_size_classUI_____storyboard_autolayout_size_UI_____storyboard_autolayout_size_classTests

- (void)setUp {
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end
