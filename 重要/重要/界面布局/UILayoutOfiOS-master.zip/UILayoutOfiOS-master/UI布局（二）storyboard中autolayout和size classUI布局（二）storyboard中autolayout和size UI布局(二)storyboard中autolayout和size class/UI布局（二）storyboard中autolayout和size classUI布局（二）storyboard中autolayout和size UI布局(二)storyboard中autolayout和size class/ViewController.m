//
//  ViewController.m
//  UI布局（二）storyboard中autolayout和size classUI布局（二）storyboard中autolayout和size UI布局(二)storyboard中autolayout和size class
//
//  Created by huangchengdu on 16/1/20.
//  Copyright © 2016年 huangchengdu. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBarHidden = YES;
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
