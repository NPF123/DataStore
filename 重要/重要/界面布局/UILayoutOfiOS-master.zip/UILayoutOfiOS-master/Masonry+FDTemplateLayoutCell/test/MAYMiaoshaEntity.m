//
//  MAYMiaoshaEntity.m
//  hhm
//
//  Created by yifan on 15/8/17.
//  Copyright (c) 2015年 maxwin. All rights reserved.
//

#import "MAYMiaoshaEntity.h"

@implementation MAYMiaoshaEntity

@end
