//
//  AppDelegate.h
//  SizeClass 和AutoLayout教程2
//
//  Created by 黄成都 on 15/11/1.
//  Copyright © 2015年 黄成都. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

