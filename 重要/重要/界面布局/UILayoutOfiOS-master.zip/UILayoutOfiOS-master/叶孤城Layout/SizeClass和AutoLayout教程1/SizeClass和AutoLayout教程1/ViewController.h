//
//  ViewController.h
//  SizeClass和AutoLayout教程1
//
//  Created by 黄成都 on 15/11/1.
//  Copyright © 2015年 黄成都. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

