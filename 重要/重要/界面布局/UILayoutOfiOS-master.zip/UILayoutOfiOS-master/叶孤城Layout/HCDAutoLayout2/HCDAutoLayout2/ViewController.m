//
//  ViewController.m
//  HCDAutoLayout2
//
//  Created by yifan on 15/9/6.
//  Copyright (c) 2015年 黄成都. All rights reserved.
//
#warning http://www.jianshu.com/p/3d6b2341fd83
#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
