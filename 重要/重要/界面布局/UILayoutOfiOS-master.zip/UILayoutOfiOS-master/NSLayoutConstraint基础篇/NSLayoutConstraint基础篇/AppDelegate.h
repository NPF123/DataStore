//
//  AppDelegate.h
//  NSLayoutConstraint基础篇
//
//  Created by huangchengdu on 16/3/23.
//
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

