//
//  ViewController.h
//  开始iOS 7中自动布局教程(二)
//
//  Created by huangchengdu on 16/1/21.
//  Copyright © 2016年 huangchengdu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

