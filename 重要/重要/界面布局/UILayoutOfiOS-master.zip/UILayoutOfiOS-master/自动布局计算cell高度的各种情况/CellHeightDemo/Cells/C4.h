//
//  C4.h
//  CellHeightDemo
//
//  Created by Haven on 21/2/14.
//  Copyright (c) 2014 LF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface C4 : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *i;
@property (weak, nonatomic) IBOutlet UITextView *t;

@end
