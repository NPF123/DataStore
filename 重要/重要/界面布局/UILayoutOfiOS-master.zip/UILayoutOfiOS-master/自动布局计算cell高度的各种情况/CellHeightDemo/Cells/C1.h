//
//  C1.h
//  CellHigthDemo
//
//  Created by Haven on 19/2/14.
//  Copyright (c) 2014 LF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface C1 : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *i;
@property (weak, nonatomic) IBOutlet UILabel *t;
@end
