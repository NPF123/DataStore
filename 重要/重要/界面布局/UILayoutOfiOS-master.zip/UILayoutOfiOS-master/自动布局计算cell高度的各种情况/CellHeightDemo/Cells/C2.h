//
//  C2.h
//  CellHeightDemo
//
//  Created by Haven on 21/2/14.
//  Copyright (c) 2014 LF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface C2 : UITableViewCell
@property (weak, nonatomic) IBOutlet UITextView *t;

@end
