//  图片文字垂直对齐按钮
//  VerticalUIButton.h
//  XMShare
//
//  Created by Amon on 15/8/6.
//  Copyright (c) 2015年 GodPlace. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VerticalUIButton : UIButton

@end
