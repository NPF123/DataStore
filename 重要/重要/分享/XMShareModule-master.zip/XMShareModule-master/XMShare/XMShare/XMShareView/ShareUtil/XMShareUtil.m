//
//  XMShareUtil.m
//  XMShare
//
//  Created by Amon on 15/8/7.
//  Copyright (c) 2015年 GodPlace. All rights reserved.
//

#import "XMShareUtil.h"

@implementation XMShareUtil


@end
