//
//  JZCourseViewController.h
//  chuanke
//
//  Created by jinzelu on 15/7/22.
//  Copyright (c) 2015年 jinzelu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JZCourseViewController : UIViewController

@property(nonatomic, strong) UITableView *tableView;

@end
