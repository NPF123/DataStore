//
//  VedioDetailViewController.h
//  aoyouHH
//
//  Created by jinzelu on 15/5/20.
//  Copyright (c) 2015年 jinzelu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VedioDetailViewController : UIViewController

@property(nonatomic, strong) NSString *FileUrl;

@end
