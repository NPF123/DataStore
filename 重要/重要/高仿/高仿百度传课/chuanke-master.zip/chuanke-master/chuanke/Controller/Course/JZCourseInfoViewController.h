//
//  JZCourseInfoViewController.h
//  chuanke
//
//  Created by jinzelu on 15/7/28.
//  Copyright (c) 2015年 jinzelu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JZCourseInfoViewController : UIViewController

@property(nonatomic, strong) NSString *Brief;


@end
