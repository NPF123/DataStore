//
//  JZSchoolViewController.h
//  chuanke
//
//  Created by jinzelu on 15/7/28.
//  Copyright (c) 2015年 jinzelu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JZSchoolViewController : UIViewController

@property (nonatomic, strong) NSString    *SID;/**< 学校ID */
@property (nonatomic, strong) UITableView *tableView;

@end
