//
//  JZSchoolModel.m
//  chuanke
//
//  Created by jinzelu on 15/7/28.
//  Copyright (c) 2015年 jinzelu. All rights reserved.
//

#import "JZSchoolModel.h"

@implementation JZSchoolModel

@end
