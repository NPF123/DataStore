//
//  JZCourseDetailModel.m
//  chuanke
//
//  Created by jinzelu on 15/7/27.
//  Copyright (c) 2015年 jinzelu. All rights reserved.
//

#import "JZCourseDetailModel.h"
#import "MJExtension.h"

@implementation JZCourseDetailModel

//+(void)load{
//    [JZCourseDetailModel setupObjectClassInArray:^NSDictionary*{
//        return @{
//                 @"StepList":@"StepList"
//                 };
//    }];
//}

@end
