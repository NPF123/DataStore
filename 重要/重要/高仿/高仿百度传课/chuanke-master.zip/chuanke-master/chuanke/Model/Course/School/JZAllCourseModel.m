//
//  JZAllCourseModel.m
//  chuanke
//
//  Created by jinzelu on 15/7/29.
//  Copyright (c) 2015年 jinzelu. All rights reserved.
//

#import "JZAllCourseModel.h"

@implementation JZAllCourseModel

@end
