//
//  JZClassListModel.m
//  chuanke
//
//  Created by jinzelu on 15/7/27.
//  Copyright (c) 2015年 jinzelu. All rights reserved.
//

#import "JZClassListModel.h"

@implementation JZClassListModel

@end
