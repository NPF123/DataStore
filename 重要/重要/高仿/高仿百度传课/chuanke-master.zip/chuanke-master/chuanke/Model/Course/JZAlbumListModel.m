//
//  JZAlbumListModel.m
//  chuanke
//
//  Created by jinzelu on 15/7/23.
//  Copyright (c) 2015年 jinzelu. All rights reserved.
//

#import "JZAlbumListModel.h"

@implementation JZAlbumListModel

@end
