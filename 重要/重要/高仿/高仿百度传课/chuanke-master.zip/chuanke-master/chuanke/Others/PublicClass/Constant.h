//
//  Constant.h
//  chuanke
//
//  Created by jinzelu on 15/7/22.
//  Copyright (c) 2015年 jinzelu. All rights reserved.
//

#ifndef chuanke_Constant_h
#define chuanke_Constant_h


#define UID @"4597633"
#define VERSION @"2.4.1.2"
//友盟Appkey
#define UMAPPKEY @"55a37e7f67e58e1aac00211f"

#endif
