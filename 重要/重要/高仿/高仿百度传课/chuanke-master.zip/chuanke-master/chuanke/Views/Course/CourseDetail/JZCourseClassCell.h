//
//  JZCourseClassCell.h
//  chuanke
//
//  Created by jinzelu on 15/7/27.
//  Copyright (c) 2015年 jinzelu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JZClassListModel.h"

@interface JZCourseClassCell : UITableViewCell

@property(nonatomic, strong) JZClassListModel *jzClassM;/**< 数据 */

@end
