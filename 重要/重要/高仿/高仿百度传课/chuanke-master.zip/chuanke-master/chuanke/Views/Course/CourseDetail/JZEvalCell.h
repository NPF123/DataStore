//
//  JZEvalCell.h
//  chuanke
//
//  Created by jinzelu on 15/7/28.
//  Copyright (c) 2015年 jinzelu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JZEvalModel.h"

@interface JZEvalCell : UITableViewCell

@property(nonatomic, strong) JZEvalModel *jzEvalM;

@end
