//
//  JZCourseCell.h
//  chuanke
//
//  Created by jinzelu on 15/7/23.
//  Copyright (c) 2015年 jinzelu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JZCourseListModel.h"

@interface JZCourseCell : UITableViewCell

@property(nonatomic, strong) JZCourseListModel *jzCourseM;/**< 课程数据 */

@end
