# chuanke
高仿百度传课iOS版，版本号2.4.1.2。/**作者：ljz ; Q Q：863784757 ; 注明：版权所有，转载请注明出处，不可用于其他商业用途。 */

运行环境：xcode6.3  ios8.3(再往上的版本没试过)

#
截图链接：
http://blog.csdn.net/l863784757/article/details/47253133
