//
//  SXPhotoView.m
//  81 - 网易新闻
//
//  Created by 董 尚先 on 15/2/4.
//  Copyright (c) 2015年 ShangxianDante. All rights reserved.
//

#import "SXPhotoView.h"

@implementation SXPhotoView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
