//
//  HZNavigationController.h
//  photoBrowser
//
//  Created by huangzhenyu on 15/7/2.
//  Copyright (c) 2015年 eamon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HZNavigationController : UINavigationController

@end
