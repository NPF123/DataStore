//
//  personInfo.m
//  dddddddddd
//
//  Created by huangzhenyu on 15/8/4.
//  Copyright (c) 2015年 eamon. All rights reserved.
//

#import "personInfo.h"

@implementation personInfo
- (NSArray *)srcStringArray
{
    if (!_srcStringArray) {
        _srcStringArray = [NSArray array];
    }
    return _srcStringArray;
}
@end
