//
//  AppDelegate.h
//  HZPhotoBrowserDemo
//
//  Created by huangzhenyu on 15/8/4.
//  Copyright (c) 2015年 eamon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

