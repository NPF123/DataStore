//
//  personInfo.h
//  dddddddddd
//
//  Created by huangzhenyu on 15/8/4.
//  Copyright (c) 2015年 eamon. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface personInfo : NSObject
@property (nonatomic,strong) NSString *string;
@property (nonatomic,strong) NSString *introStr;
@property (nonatomic,strong) NSArray *srcStringArray;
@end
