Date.prototype.shortFormat = function() {
	return (this.getMonth() + 1) + "/" + this.getDate() + "/" + this.getFullYear();
};