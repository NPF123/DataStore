// var message = "some string";
// console.log(typeof message);
// console.log(typeof(message));
// console.log(typeof 95);
// console.log(typeof null);


// var message;
// console.log(message == undefined);
// console.log(typeof message);
// console.log(typeof age);//没有声明的变量


// var car = null;
// console.log(typeof car);
// console.log(null == undefined);

// var result = Number.MAX_VALUE + Number.MAX_VALUE;
// console.log(isFinite(result));
// console.log(NaN == NaN);
// console.log(isNaN(NaN));
// console.log(isNaN("10"));
// console.log(isNaN("blue"));

// console.log(Number("hello world!"));
// console.log(Number(""));
// console.log(Number("000011"));
// console.log(Number(true));
// console.log(parseInt("0xAF", 16));

// console.log(String(10));
// console.log(String(true));
// console.log(String(null));
// console.log(String(undefined));

// var s1 = "2";
// var s2 = "z";
// var b = false;
// var f = 1.1;
// var o = {
// 	valueOf:function(){
// 		return -1;
// 	}
// };
// console.log(s1++);
// console.log(s2++);
// console.log(b++);
// console.log(f--);
// console.log(o--);

// console.log(!false);
// console.log(!"bue");
// console.log(!0);
// console.log(!NaN);
// console.log(!"";)
// console.log(!23456);

// var obj1 = new Object();
// var obj2 = new Object();
// console.log(obj1 && obj2);
// console.log(obj1 && 0);


// with(location){
// 	var qs = search.substring();
// 	var hostName = hostname;
// 	var url = href;
// 	console.log(qs + hostname + url);
// }


// var i = 1;
// switch(i){
// 	case 25:
// 		alert("25");
// 		break;
// 	case 35:
// 		alert("35");
// 		break;
// 	case 45:
// 		alert("45");
// 		break;
// 	default:
// 		alert("other");
// }
// switch("hello world"){
// 	case "hello" + " world":
// 		alert("greeting was found.");
// 		break;
// 	case "goodbye":
// 		alert("Closing was found.");
// 		break;
// 	default:
// 		alert("Unexpected message was found.");
// }



