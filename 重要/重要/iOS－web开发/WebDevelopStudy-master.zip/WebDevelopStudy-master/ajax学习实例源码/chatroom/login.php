<html>
<head>
<meta http-equiv="content-type" content="text/html;charset=utf-8"/>
</head>

<center>
<h1>欢迎登陆聊天室</h1>
<form action="loginController.php" method="post">
用户名：<input type="text" name="username"/></br>
密码：<input type="password" name="passwd"/></br>

<input type="submit" value="登陆聊天室"/>

</form>
</center>
</html>