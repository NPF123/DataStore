Flashlight icon retreived from http://www.ggdown.com/data/soft_img/1293348425367.png via google images
