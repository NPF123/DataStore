//
//  main.m
//  html5测试
//
//  Created by huangchengdu on 15/12/30.
//  Copyright © 2015年 huangchengdu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
