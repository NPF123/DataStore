var flashcards;
(function () {
  flashcards = [
    ["Ice cream", "ice-cream.png"],
    ["Pizza", "pizza.png"],
    ["Soda", "soda.png"],
  ];
}());
