
  * [DeviceMotionEvent Class Reference](http://developer.apple.com/library/safari/#documentation/SafariDOMAdditions/Reference/DeviceMotionEventClassRef/DeviceMotionEvent/DeviceMotionEvent.html)

  * [DeviceOrientationEvent Class Reference](http://developer.apple.com/library/safari/#documentation/SafariDOMAdditions/Reference/DeviceOrientationEventClassRef/DeviceOrientationEvent/DeviceOrientationEvent.html#//apple_ref/doc/uid/TP40010526)

Note: If the device does not have a gyroscope, then you may need to implement your own gravity direction detection using a low pass filter.



JavaScript demo taken from http://www.peterfriese.de/how-to-use-the-gyroscope-of-your-iphone-in-a-mobile-web-app/

Icon taken from http://a1.phobos.apple.com/us/r1000/020/Purple/70/d1/b1/mzi.ubhrfsnm.png
