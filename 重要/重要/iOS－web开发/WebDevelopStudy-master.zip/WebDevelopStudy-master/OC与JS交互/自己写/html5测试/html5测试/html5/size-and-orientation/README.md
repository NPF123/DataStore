This app will show you the width and height of your browser window.
