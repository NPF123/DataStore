(function () {
  "use strict";

  module.exports = {
    port: 3080
  };
}());
