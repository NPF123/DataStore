JavaScript demo taken from http://www.peterfriese.de/how-to-use-the-gyroscope-of-your-iphone-in-a-mobile-web-app/

Icon taken from http://a1.phobos.apple.com/us/r1000/020/Purple/70/d1/b1/mzi.ubhrfsnm.png
