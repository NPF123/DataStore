//
//  ViewController.m
//  WKWebView的使用及js交互
//
//  Created by huangchengdu on 15/12/17.
//  Copyright © 2015年 huangchengdu. All rights reserved.
//

#warning 参考博客地址：http://liuyanwei.jumppo.com/2015/10/17/ios-webView.html

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
