//
//  ObjCJSAppDelegate.h
//  ObjCJS
//
//  Created by Steve Smith on 1/14/11.
//

#import <UIKit/UIKit.h>

@interface ObjCJSAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

