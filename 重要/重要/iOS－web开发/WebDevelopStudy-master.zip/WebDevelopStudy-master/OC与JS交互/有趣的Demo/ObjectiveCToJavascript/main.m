//
//  main.m
//  ObjCJS
//
//  Created by Steve Smith on 1/14/11.
//  Copyright 2011 Chariot Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
