//
//  main.m
//  NativeJsWebView
//
//  Created by Peter Traeg on 5/27/13.
//  Copyright (c) 2013 Peter Traeg. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "njwAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([njwAppDelegate class]));
    }
}
