//
//  AppDelegate.h
//  JS_OjbC_Interaction_Demo
//
//  Created by caolongyao on 15/12/12.
//  Copyright © 2015年 iOSLittleSquad. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

