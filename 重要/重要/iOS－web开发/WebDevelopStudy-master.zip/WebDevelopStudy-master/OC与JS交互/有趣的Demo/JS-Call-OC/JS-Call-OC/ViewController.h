//
//  ViewController.h
//  JS-Call-OC
//
//  Created by Jakey on 14-8-6.
//  Copyright (c) 2014年 www.skyfox.org. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
- (IBAction)reload:(id)sender;
@property (weak, nonatomic) IBOutlet UIWebView *myWebView;

@end
