JS-Call-OC
==========

javascript 调用objective-c 方法 及传参

如果SDK版本大于IO7可以用下JavaScriptCore.framework 框架,进行与 ObJective-c的交互,下边是个demo

https://github.com/shaojiankui/JavaScriptCore-Demo

JavaScriptCore.framework ：iOS7 中新加入的框架，用来处理JavaScript。JavaScriptCore 是苹果 Safari 浏览器的 JavaScript 引擎，JavaScriptCor在 OS X 平台上很早就存在的，而在 iOS 平台，直到IOS7才对外开放，并提供了 Objective-C 的接口
